#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/../hit-diagnostic-publish" && pwd)"
cd "$root"
source tools/godot/env.sh
out="$root/../hit-polish-20261108"
files=(BoardProjection.cs PaintedSurface.cs PaintedSurfaceBroadPhaseChecks.cs)
for variant in baseline candidate; do
 for file in "${files[@]}"; do
  if [[ "$variant" == baseline ]]; then
   git show 0e7861b26139399512b83fabda1c6b4479f272b7:godot/Presentation/"$file" > "$out/godot/Presentation/$file"
  else
   cp "godot/Presentation/$file" "$out/godot/Presentation/"
  fi
 done
 sha256sum "${files[@]/#/$out/godot/Presentation/}" > "$out/$variant-inputs.sha256"
 "$DOTNET_ROOT/dotnet" build "$out/godot/Empire.csproj" --disable-build-servers -m:1 -p:UseSharedCompilation=false > "$out/$variant-build.log" 2>&1
 for n in 1 2 3; do
  EMPIRE_HIT_OUTPUT="$out/$variant-fixed-$n" EMPIRE_HIT_CANDIDATE=1 EMPIRE_HIT_MODE=fixed60 XDG_DATA_HOME="$out/user-$variant-$n" \
   bash tools/godot/native-process.sh "$out/$variant-fixed-$n.log" "$variant C04 fixed $n" "$GODOT_NET" --headless --fixed-fps 60 --path "$out/godot" res://Scenes/HitDiagnosticChecks.tscn
 done
 for n in 1 2; do
  EMPIRE_HIT_OUTPUT="$out/$variant-realtime-$n" EMPIRE_HIT_CANDIDATE=1 EMPIRE_HIT_MODE=realtime XDG_DATA_HOME="$out/user-$variant-real-$n" \
   bash tools/godot/native-process.sh "$out/$variant-realtime-$n.log" "$variant C04 realtime $n" "$GODOT_NET" --headless --path "$out/godot" res://Scenes/HitDiagnosticChecks.tscn
 done
done
python3 tools/godot/hit-diagnostic/summarize.py "$out"/{baseline,candidate}-{fixed-1,fixed-2,fixed-3,realtime-1,realtime-2} > "$out/comparison-summary.json"
