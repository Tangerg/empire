#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/../hit-diagnostic-publish" && pwd)"
cd "$root"
source tools/godot/env.sh
out="$root/../hit-polish-20261108"
for fault in stale-copy shrunken-broad-phase; do
 cp godot/Presentation/{BoardProjection.cs,PaintedSurface.cs,PaintedSurfaceBroadPhaseChecks.cs} "$out/godot/Presentation/"
 python3 - "$out/godot/Presentation" "$fault" <<'PY'
from pathlib import Path
import sys
folder=Path(sys.argv[1]);fault=sys.argv[2]
if fault=='stale-copy':
 p=folder/'BoardProjection.cs';s=p.read_text();old='            ProjectedBounds = Bounds(value);';assert old in s;s=s.replace(old,'            // Deliberate fault: retain stale copied extrema.')
else:
 p=folder/'PaintedSurface.cs';s=p.read_text();old='patch.Maximum.X < bounds.Position.X';assert old in s;s=s.replace(old,'patch.Maximum.X < bounds.Position.X + 4')
p.write_text(s)
PY
 "$DOTNET_ROOT/dotnet" build "$out/godot/Empire.csproj" --disable-build-servers -m:1 -p:UseSharedCompilation=false > "$out/negative-$fault-build.log" 2>&1
 set +e
 XDG_DATA_HOME="$out/user-negative-$fault" bash tools/godot/native-process.sh "$out/negative-$fault.log" "$fault" "$GODOT_NET" --headless --path "$out/godot" res://Scenes/PaintedSurfaceBroadPhaseChecks.tscn
 code=$?
 set -e
 echo "$code" > "$out/negative-$fault.exit"
 [[ "$code" -ne 0 ]] || { echo "Deliberate fault passed unexpectedly" >&2; exit 1; }
done
cp godot/Presentation/{BoardProjection.cs,PaintedSurface.cs,PaintedSurfaceBroadPhaseChecks.cs} "$out/godot/Presentation/"
"$DOTNET_ROOT/dotnet" build "$out/godot/Empire.csproj" --disable-build-servers -m:1 -p:UseSharedCompilation=false > "$out/restored-build.log" 2>&1
XDG_DATA_HOME="$out/user-restored" bash tools/godot/native-process.sh "$out/restored-oracle.log" "Restored bounds" "$GODOT_NET" --headless --path "$out/godot" res://Scenes/PaintedSurfaceBroadPhaseChecks.tscn
